<table>
<tr>
<th>Story</th>
</tr>
<tr>
<td>

**Als** ...

**Möchte ich** ...

**um** ...
</td>
</tr>
</table>

<table>
<tr>
<th>Akzeptanzkriterien</th>
</tr>
<tr>
<td>

* [ ] 1
* [ ] 2
* [ ] 3
</td>
</tr>
</table>

<table>
<tr>
<th>Zusätzliche Informationen</th>
</tr>
<tr>
<td>

**Technische Details**

Zusätzliche Informatione/Details hier.
</td>
</tr>
</table>

<table>
<tr>
<th>Q & A / Fragen und Antworten</th>
</tr>
<tr>
<td>

**Frage?**

Antwort
</td>
</tr>
</table>